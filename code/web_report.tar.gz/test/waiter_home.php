<?php
	require_once("connectdb.php");
	require_once("header_mobile.php");
?>
	<form action="add_order.php">
		<input type="submit" value="Νέα Παραγγελία"/>
		</form>
	
	<form action="listorder_by_username.php">
		<input type="submit" value="Οι παραγγελίες μου"/>
		</form>
	
	
	

<?php
	require_once("footer_mobile.php");
?>

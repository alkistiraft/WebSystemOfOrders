  </td>
   </tr>
    
   <tr style="background-color:pink;">
        <td height="30"> 
        <div style="position:relative;top:-26px;width=800;height=30;"> 
                <p style="position:absolute;top:4px;left:5;"> Made by alkisti </p>
                <p  style="position:absolute;top:4px;left:645px;"> Copyright@2013 </p>
             </div>
</td>
   </tr>
  

</table>
</body>
</html>

</td>
   </tr>
    
   <tr style="background-color:pink;">
        <td height="50"> 
        <div style="position:relative;top:-47px;width=800;height=50;"> 
                <p style="position:absolute;top:6;left:5; font-size:30;"> Made by alkisti </p>
                <p style="position:absolute;top:6;left:70%; font-size:30;"> Copyright@2013 </p>
             </div>
</td>
   </tr>
  

</table>
</body>
</html>

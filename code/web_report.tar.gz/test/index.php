<?php
	header( 'Location: /test/home.php' );
?>

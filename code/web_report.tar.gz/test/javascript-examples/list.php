<?php
   require_once("header.php");

echo '<table border="1">';
echo "<thead>";
echo '<tr>';
echo '<td>Username</td>';
echo '<td> Proionta </td>' ;
echo '<td> Kostos </td>';
echo'</tr>';
echo "</thead>";
echo '</table>';








require_once("footer.php");
?>
